#ifndef SOURCE
#define SOURCE
//#include "backend.cpp"
class so{
public:
    int sourc;
    //Train* m;
};

#endif // SOURCE

