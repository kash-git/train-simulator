// speedometer.h
#ifndef SPEEDOMETER_H
#define SPEEDOMETER_H

#include <QWidget>
#include <QTimer>
#include <QObject>
#include <trainsim.h>


class Speedometer : public QWidget
{
    Q_OBJECT

public:
    explicit Speedometer(QWidget *parent=0);
    ~Speedometer();
   // trainSim t;
public slots:
   // void myfunction();

protected:
    void paintEvent(QPaintEvent *event) override;
//    void onTimer();
//    double getCurrentSpeed();
//    void updateSpeedometerDisplay(double speed);

private:
    int m_speed;
    QTimer *m_timer;
    trainSim *back;
    int width;
    int height;
    int side;

private slots:
    void valueGeneratedSlot(int);
};

#endif // SPEEDOMETER_H
